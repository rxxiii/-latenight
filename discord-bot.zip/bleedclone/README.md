# Discord Bot — Moderation / Welcome / Roles / Tickets / Giveaways / VoiceMaster

A discord.py bot with **hybrid commands** — every command works as both a
`,prefix command` and a `/slash command`.

## Setup

1. **Create the bot application**
   - Go to https://discord.com/developers/applications → New Application
   - Bot tab → Reset Token → copy it
   - Enable these under Privileged Gateway Intents: **Server Members Intent**, **Message Content Intent**
   - OAuth2 → URL Generator → scopes: `bot`, `applications.commands` → permissions: `Administrator` (simplest) or pick individually (Manage Roles, Manage Channels, Manage Messages, Kick/Ban Members, Moderate Members, Manage Guild) → use the generated URL to invite it to your server

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` and paste your bot token. Optionally set `DEV_GUILD_ID` to your
   test server's ID while developing — slash commands sync instantly to one
   server instead of taking up to an hour to propagate globally.

4. **Run**
   ```bash
   python bot.py
   ```

## Commands

Default prefix is `,` (change per-server with `,prefix set <new prefix>`).

**Moderation** (needs relevant Discord permissions)
- `ban <member> [reason]`, `unban <user_id>`, `kick <member> [reason]`
- `mute <member> [duration] [reason]` (timeout, e.g. `10m`, `2h`, `1d`), `unmute <member>`
- `warn <member> [reason]`, `warnings [member]`, `clearwarnings <member>`
- `purge <amount>`, `lock [channel]`, `unlock [channel]`, `slowmode <seconds>`

**Welcome / Goodbye / Auto-responders**
- `welcome channel <#channel>`, `welcome message <text>`, `welcome test`
- `goodbye channel <#channel>`, `goodbye message <text>`
- Placeholders: `{user}` `{username}` `{server}` `{membercount}`
- `autoresponder add <trigger> <response> [exact]`, `autoresponder remove <trigger>`, `autoresponder list`

**Reaction / Button roles + Starboard**
- `reactionrole add <message_id> <emoji> <role>`, `reactionrole remove <message_id> <emoji>`
- `buttonrole <role> [label] [#channel]` — posts a click-to-toggle role button
- `starboard channel <#channel>`, `starboard threshold <count>` — star a message enough times and it gets reposted

**Tickets**
- `ticketpanel <category> <support_role> [title] [description] [#channel]` — posts an "Open Ticket" button
- `ticketclose` (run inside a ticket channel), `ticketadd <member>`, `ticketremove <member>`

**Giveaways**
- `gstart <duration> <winners> <prize>` (e.g. `,gstart 1h 1 Nitro`)
- `gend <message_id>`, `greroll <message_id>`

**VoiceMaster**
- `voicemaster-setup` (run once per server) — creates a "Join to Create" channel
- Inside your temp channel: `voice-lock`, `voice-unlock`, `voice-limit <n>`, `voice-rename <name>`, `voice-kick <member>`, `voice-claim`

**Utility**
- `ping`, `userinfo [member]`, `serverinfo`, `prefix`, `prefix set <symbol>`

## Notes / limitations

- Data is stored locally in `bleedclone.sqlite3` (created automatically on first run).
- This covers the modules you asked for from bleed.bot's feature set. It does **not**
  include things like antinuke, music playback, or Spotify/Last.fm integration —
  those depend on paid third-party APIs or are large standalone subsystems; happy
  to help add any of them next if you want to go further.
- Run `python bot.py` from inside this folder so relative imports (`cogs.*`, `database`) resolve.
